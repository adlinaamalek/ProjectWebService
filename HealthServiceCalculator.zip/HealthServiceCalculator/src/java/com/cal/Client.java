package com.cal;

import com.health.calculator.HealthService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Client", urlPatterns = {"/Client"})
public class Client extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HealthService service = new HealthService();

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body><h1>Health Service Result</h1>");

        try {
            String action = request.getParameter("action");
            if (action == null || action.isEmpty()) {
                out.println("<p>No action provided</p>");
                return;
            }

            switch (action) {
                case "bmi": {
                    double weight = Double.parseDouble(request.getParameter("weight"));
                    double height = Double.parseDouble(request.getParameter("height"));
                    double bmi = service.calculateBMI(weight, height);
                    response.sendRedirect("bmi.jsp?weightKg=" + weight + "&heightCm=" + height + "&bmi=" + bmi);
                    return;
                }

                case "bodyfat": {
                    double bmi = Double.parseDouble(request.getParameter("bmi"));
                    int age = Integer.parseInt(request.getParameter("age"));
                    String gender = request.getParameter("gender");
                    double bfp = service.calculateBodyFat(bmi, age, gender);
                    out.println("<p>Body Fat Percentage: " + bfp + "%</p>");
                    break;
                }

                case "calories": {
                    String goal = request.getParameter("goal");
                    int calories = service.calculateCalories(goal);
                    out.println("<p>Daily Calories for " + goal + ": " + calories + " kcal</p>");
                    break;
                }

                case "meal": {
                    String goal = request.getParameter("goal");
                    String meal = service.generateMealPlan(goal);
                    out.println("<p>Suggested Meal Plan: " + meal + "</p>");
                    break;
                }

                case "steps": {
                    int current = Integer.parseInt(request.getParameter("current"));
                    int goal = Integer.parseInt(request.getParameter("goal"));
                    int remaining = service.trackSteps(current, goal);
                    out.println("<p>Steps Remaining: " + remaining + "</p>");
                    break;
                }
                
                case "userinfo": {
                    String name = request.getParameter("name");
                    String id = request.getParameter("id");
                    String gender = request.getParameter("gender");
                    double weight = Double.parseDouble(request.getParameter("weight"));
                    double height = Double.parseDouble(request.getParameter("height"));
                    int age = Integer.parseInt(request.getParameter("age"));

                    String info = service.displayUserInfo(name, id, gender, weight, height, age);
                    out.println("<p>" + info + "</p>");
                    break;
                }

                case "calculateage": {
                    String ic = request.getParameter("ic");
                    int age = service.calculateAgeFromIC(ic);
                    out.println("<p>Age based on IC: " + age + " years old</p>");
                    break;
                }
                
                case "agefromic": {
                    String ic = request.getParameter("ic");
                    int age = service.calculateAgeFromIC(ic);
                    out.println("<p>Age based on IC: " + age + " years old</p>");
                    break;
                }



                default:
                    out.println("<p>Unknown action: " + action + "</p>");
            }
        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
            e.printStackTrace(out);
        }

        out.println("</body></html>");
    }
}
