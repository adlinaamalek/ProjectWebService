package com.cal;

import com.health.calculator.HealthService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

@WebServlet(name = "Client", urlPatterns = {"/Client"})
public class Client extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HealthService service = new HealthService();
        
            out.println("<html><head><title>Health Service Result</title>");
            // Link CSS for consistent styling
            out.println("<link rel='stylesheet' href='css/style.css'>");
            out.println("</head><body>");
            out.println("<h1>Health Service Result</h1>");

        try {
            String action = request.getParameter("action");
            if (action == null || action.isEmpty()) {
                out.println("<p>No action provided</p>");
                out.println("</body></html>");
                return;
            }

            switch (action) {
                case "userinfo": {
                String name = request.getParameter("name");
                String id = request.getParameter("id");
                String gender = request.getParameter("gender");
                String weightStr = request.getParameter("weight");
                String heightStr = request.getParameter("height");
                String ageStr = request.getParameter("age");

                request.setAttribute("name", name != null ? name : "N/A");
                request.setAttribute("id", id != null ? id : "N/A");
                request.setAttribute("gender", gender != null ? gender : "N/A");
                request.setAttribute("weight", weightStr != null ? weightStr : "N/A");
                request.setAttribute("height", heightStr != null ? heightStr : "N/A");
                request.setAttribute("age", ageStr != null ? ageStr : "N/A");

                request.getRequestDispatcher("/userinfo.jsp").forward(request, response);
                break;
            }


                case "calculateage": {
                    String ic = request.getParameter("ic");
                    if (ic == null || ic.isEmpty()) {
                        request.setAttribute("errorMessage", "Please provide an IC number.");
                        request.getRequestDispatcher("/age_result.jsp").forward(request, response);
                        break;
                    }
                    try {
                        int age = service.calculateAgeFromIC(ic);
                        request.setAttribute("ic", ic);
                        request.setAttribute("age", age);
                    } catch (Exception e) {
                        request.setAttribute("errorMessage", "Error parsing IC: " + e.getMessage());
                    }
                    request.getRequestDispatcher("/calculateage.jsp").forward(request, response);
                    break;
                }

                
                case "bmi": {
                    double weight = Double.parseDouble(request.getParameter("weight"));
                    double height = Double.parseDouble(request.getParameter("height"));

                    double bmi = service.calculateBMI(weight, height);
                    String category = service.getBMICategory(bmi);

                    String url = String.format("bmi.jsp?weightKg=%s&heightCm=%s&bmi=%.2f&category=%s",
                            URLEncoder.encode(String.valueOf(weight), "UTF-8"),
                            URLEncoder.encode(String.valueOf(height), "UTF-8"),
                            bmi,
                            URLEncoder.encode(category, "UTF-8"));

                    response.sendRedirect(url);
                    return;
                }

                case "bodyfat": {
                    String gender = request.getParameter("gender");
                    double height = Double.parseDouble(request.getParameter("height"));
                    double waist = Double.parseDouble(request.getParameter("waist"));
                    double neck = Double.parseDouble(request.getParameter("neck"));
                    double hip = 0;
                    if ("female".equalsIgnoreCase(gender)) {
                        String hipStr = request.getParameter("hip");
                        hip = hipStr != null && !hipStr.isEmpty() ? Double.parseDouble(hipStr) : 0;
                    }

                    double bfp = service.calculateBodyFatUSNavy(gender, height, waist, neck, hip);
                    String category = service.getBodyFatCategory(bfp, gender);

                    // Set as request attributes
                    request.setAttribute("bfp", bfp);
                    request.setAttribute("category", category);

                    // Forward to JSP for display
                    request.getRequestDispatcher("/bodyfat.jsp").forward(request, response);

                    break;
                }


                case "caloriesburn": {
                    try {
                        String weightStr = request.getParameter("weight");
                        String durationStr = request.getParameter("duration");
                        String activity = request.getParameter("activity");

                        if (weightStr == null || weightStr.isEmpty() || durationStr == null || durationStr.isEmpty()) {
                            request.setAttribute("errorMessage", "Please provide both weight and duration.");
                            request.getRequestDispatcher("/calories.jsp").forward(request, response);
                            break;
                        }

                        double weight = Double.parseDouble(weightStr);
                        double duration = Double.parseDouble(durationStr);

                        if (weight <= 0 || duration <= 0) {
                            request.setAttribute("errorMessage", "Weight and duration must be positive numbers.");
                            request.getRequestDispatcher("/calories.jsp").forward(request, response);
                            break;
                        }

                        if (activity == null || activity.trim().isEmpty()) {
                            activity = "rest"; // default activity
                        }

                        double caloriesBurned = service.calculateCaloriesBurned(weight, duration, activity);

                        request.setAttribute("activity", activity);
                        request.setAttribute("caloriesBurned", caloriesBurned);
                        request.getRequestDispatcher("/calories.jsp").forward(request, response);

                    } catch (NumberFormatException e) {
                        request.setAttribute("errorMessage", "Please enter valid numeric values for weight and duration.");
                        request.getRequestDispatcher("/calories.jsp").forward(request, response);
                    } catch (Exception e) {
                        request.setAttribute("errorMessage", e.getMessage());
                        request.getRequestDispatcher("/calories.jsp").forward(request, response);
                    }
                    break;
                }



                case "mealplanner": {
                        try {
                            String weightStr = request.getParameter("weight");
                            String heightStr = request.getParameter("height");
                            String ageStr = request.getParameter("age");
                            String gender = request.getParameter("gender");
                            String activityLevel = request.getParameter("activityLevel");
                            String goal = request.getParameter("goal");

                            if (weightStr == null || heightStr == null || ageStr == null || gender == null 
                                || activityLevel == null || goal == null
                                || weightStr.isEmpty() || heightStr.isEmpty() || ageStr.isEmpty()
                                || gender.isEmpty() || activityLevel.isEmpty() || goal.isEmpty()) {
                                request.setAttribute("errorMessage", "Please fill in all required fields for the meal planner.");
                                request.getRequestDispatcher("/meal.jsp").forward(request, response);
                                break;
                            }

                            double weight = Double.parseDouble(weightStr);
                            double height = Double.parseDouble(heightStr);
                            int age = Integer.parseInt(ageStr);

                            double bmr;
                            if ("male".equalsIgnoreCase(gender)) {
                                bmr = 10 * weight + 6.25 * height - 5 * age + 5;
                            } else if ("female".equalsIgnoreCase(gender)) {
                                bmr = 10 * weight + 6.25 * height - 5 * age - 161;
                            } else {
                                request.setAttribute("errorMessage", "Invalid gender value.");
                                request.getRequestDispatcher("/meal.jsp").forward(request, response);
                                break;
                            }

                            double activityMultiplier;
                            switch (activityLevel.toLowerCase()) {
                                case "sedentary": activityMultiplier = 1.2; break;
                                case "lightly active": activityMultiplier = 1.375; break;
                                case "moderately active": activityMultiplier = 1.55; break;
                                case "very active": activityMultiplier = 1.725; break;
                                default:
                                    request.setAttribute("errorMessage", "Invalid activity level.");
                                    request.getRequestDispatcher("/meal.jsp").forward(request, response);
                                    return;
                            }

                            double caloriesNeeded = bmr * activityMultiplier;

                            switch (goal.toLowerCase()) {
                                case "weight_loss":
                                    caloriesNeeded -= 500; // calorie deficit
                                    break;
                                case "maintenance":
                                    // no change
                                    break;
                                case "muscle_gain":
                                    caloriesNeeded += 300; // surplus
                                    break;
                                default:
                                    request.setAttribute("errorMessage", "Invalid goal.");
                                    request.getRequestDispatcher("/meal.jsp").forward(request, response);
                                    return;
                            }

                            request.setAttribute("caloriesNeeded", caloriesNeeded);
                            request.setAttribute("goal", goal.replace("_", " "));
                            request.getRequestDispatcher("/meal.jsp").forward(request, response);

                        } catch (NumberFormatException e) {
                            request.setAttribute("errorMessage", "Please enter valid numeric values for weight, height, and age.");
                            request.getRequestDispatcher("/meal.jsp").forward(request, response);
                        } catch (Exception e) {
                            request.setAttribute("errorMessage", e.getMessage());
                            request.getRequestDispatcher("/meal.jsp").forward(request, response);
                        }
                        break;
                    }


                case "steptracker": {
                    try {
                        int currentSteps = Integer.parseInt(request.getParameter("currentSteps"));
                        int goalSteps = Integer.parseInt(request.getParameter("goalSteps"));
                        double stepLength = Double.parseDouble(request.getParameter("stepLength"));
                        double weight = Double.parseDouble(request.getParameter("weight"));
                        double duration = Double.parseDouble(request.getParameter("duration"));

                        int stepsRemaining = service.trackSteps(currentSteps, goalSteps);
                        double distanceMeters = (currentSteps * stepLength) / 100.0;

                        request.setAttribute("currentSteps", currentSteps);
                        request.setAttribute("goalSteps", goalSteps);
                        request.setAttribute("stepsRemaining", stepsRemaining);
                        request.setAttribute("stepLength", stepLength);
                        request.setAttribute("weight", weight);
                        request.setAttribute("duration", duration);
                        request.setAttribute("distanceMeters", distanceMeters);

                        request.getRequestDispatcher("steps.jsp").forward(request, response);
                    } catch (NumberFormatException e) {
                        request.setAttribute("error", "Please enter valid numeric values.");
                        request.getRequestDispatcher("steps.jsp").forward(request, response);
                    }
                    break;
                }




                default:
                    out.printf("<p>Unknown action: %s</p>%n", action);
                    out.println("<br><a href='index.html'>Back to Home</a>");
                    break;
            }

        } catch (NumberFormatException nfe) {
            out.println("<p>Error: Invalid number format. Please check your inputs.</p>");
            out.println("<br><a href='index.html'>Back to Home</a>");
        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
            e.printStackTrace(out);
            out.println("<br><a href='index.html'>Back to Home</a>");
        }

        out.println("</body></html>");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("index.html");
    }
}