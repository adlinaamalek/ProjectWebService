package com.health.calculator;

import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class HealthService_Service extends Service {

    private static final QName SERVICE_NAME = new QName("http://calculator.health.com/", "HealthService");
    private static final QName PORT_NAME = new QName("http://calculator.health.com/", "HealthServiceCalculatorPort");

    public HealthService_Service(URL wsdlLocation) {
        super(wsdlLocation, SERVICE_NAME);
    }

    public HealthService_Service() {
        super(null, SERVICE_NAME); // You can provide a real WSDL URL here
    }

    public HealthService getHealthServiceCalculatorPort() {
        return super.getPort(PORT_NAME, HealthService.class);
    }

    public HealthService getHealthServicePort() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
