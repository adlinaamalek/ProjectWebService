package com.health.calculator;

import javax.jws.WebMethod;
import javax.jws.WebService;
import java.time.LocalDate;
import java.time.Period;

@WebService(serviceName = "HealthService")
public class HealthService {

    @WebMethod(operationName = "calculateAgeFromIC")
    public int calculateAgeFromIC(String ic) throws Exception {
        if (ic == null || ic.length() < 6) throw new Exception("Invalid IC format");
        String digitsOnly = ic.replaceAll("\\D", "");
        String birthDateStr = digitsOnly.substring(0, 6);
        int year = Integer.parseInt(birthDateStr.substring(0, 2));
        int month = Integer.parseInt(birthDateStr.substring(2, 4));
        int day = Integer.parseInt(birthDateStr.substring(4, 6));

        year += (year <= 25) ? 2000 : 1900;

        LocalDate birthDate = LocalDate.of(year, month, day);
        LocalDate today = LocalDate.now();

        if (birthDate.isAfter(today)) {
            throw new IllegalArgumentException("Birthdate cannot be in the future");
        }

        return Period.between(birthDate, today).getYears();
    }

    @WebMethod(operationName = "calculateBMI")
    public double calculateBMI(double weightKg, double heightCm) {
        if (weightKg <= 0 || heightCm <= 0) return -1;
        double heightM = heightCm / 100.0;
        return weightKg / (heightM * heightM);
    }

    @WebMethod(operationName = "getBMICategory")
    public String getBMICategory(double bmi) {
        if (bmi < 0) return "Invalid BMI";
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal weight";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }

    @WebMethod(operationName = "calculateBodyFatUSNavy")
    public double calculateBodyFatUSNavy(String gender, double heightCm, double waistCm, double neckCm, double hipCm) {
        if (gender == null) return -1;
        if ("male".equalsIgnoreCase(gender)) {
            if (waistCm <= neckCm) return -1;
            return 86.010 * Math.log10(waistCm - neckCm) - 70.041 * Math.log10(heightCm) + 36.76;
        } else if ("female".equalsIgnoreCase(gender)) {
            if (waistCm + hipCm <= neckCm) return -1;
            return 163.205 * Math.log10(waistCm + hipCm - neckCm) - 97.684 * Math.log10(heightCm) - 78.387;
        } else {
            return -1;
        }
    }

    @WebMethod(operationName = "getBodyFatCategory")
    public String getBodyFatCategory(double bfp, String gender) {
        if (bfp < 0 || gender == null) return "Invalid input";
        if ("male".equalsIgnoreCase(gender)) {
            if (bfp < 6) return "Essential fat";
            else if (bfp < 14) return "Athletes";
            else if (bfp < 18) return "Fitness";
            else if (bfp < 25) return "Average";
            else return "Obese";
        } else {
            if (bfp < 14) return "Essential fat";
            else if (bfp < 21) return "Athletes";
            else if (bfp < 25) return "Fitness";
            else if (bfp < 32) return "Average";
            else return "Obese";
        }
    }

    @WebMethod(operationName = "calculateCaloriesBurned")
    public double calculateCaloriesBurned(double weightKg, double durationMinutes, String activity) {
        if (weightKg <= 0 || durationMinutes <= 0) {
            // Invalid inputs
            return -1;
        }
        
        double met;
        if (activity == null || activity.trim().isEmpty()) {
            activity = "rest";
        }

        switch (activity.toLowerCase()) {
            case "running":
                met = 9.8;
                break;
            case "walking":
                met = 3.5;
                break;
            case "cycling":
                met = 7.5;
                break;
            case "swimming":
                met = 8.0;
                break;
            case "rest":
                met = 1.0;
                break;
            default:
                // Unknown activity defaults to resting MET
                met = 1.0;
        }

        // Calories burned = MET * weight(kg) * duration(hr)
        return met * weightKg * (durationMinutes / 60.0);
    }

    @WebMethod(operationName = "trackSteps")
    public int trackSteps(int currentSteps, int goalSteps) {
        int remaining = goalSteps - currentSteps;
        return remaining > 0 ? remaining : 0;
    }

    @WebMethod(operationName = "suggestMealPlan")
    public String suggestMealPlan(double calories) {
        if (calories < 1500) {
            return "Light meals with plenty of vegetables and lean proteins.";
        } else if (calories < 2500) {
            return "Balanced meals including carbohydrates, proteins, and healthy fats.";
        } else {
            return "Higher calorie meals rich in protein and healthy fats to support muscle gain.";
        }
    }

    @WebMethod(operationName = "calculateCalorieGoal")
    public double calculateCalorieGoal(double tdee, String goal) {
        if (goal == null) return tdee;
        switch (goal.toLowerCase()) {
            case "weight loss": return tdee - 500;
            case "muscle gain": return tdee + 400;
            case "maintenance":
            default: return tdee;
        }
    }

    // Add BMR calculation (needed by mealplanner servlet)
    @WebMethod(operationName = "calculateBMR")
    public double calculateBMR(double weightKg, double heightCm, int age, String gender) {
        if (weightKg <= 0 || heightCm <= 0 || age <= 0 || gender == null) return -1;
        if ("male".equalsIgnoreCase(gender)) {
            return 88.362 + (13.397 * weightKg) + (4.799 * heightCm) - (5.677 * age);
        } else if ("female".equalsIgnoreCase(gender)) {
            return 447.593 + (9.247 * weightKg) + (3.098 * heightCm) - (4.330 * age);
        } else {
            return -1;
        }
    }

    // Add activity factor getter (needed by mealplanner servlet)
    @WebMethod(operationName = "getActivityFactor")
    public double getActivityFactor(String activityLevel) {
        if (activityLevel == null) return 1.2;
        switch (activityLevel.toLowerCase()) {
            case "sedentary": return 1.2;
            case "light": return 1.375;
            case "moderate": return 1.55;
            case "active": return 1.725;
            case "very active": return 1.9;
            default: return 1.2;
        }
    }

    // Calculate TDEE based on BMR and activity factor
    @WebMethod(operationName = "calculateTDEE")
    public double calculateTDEE(double bmr, double activityFactor) {
        if (bmr <= 0 || activityFactor <= 0) return -1;
        return bmr * activityFactor;
    }
}
