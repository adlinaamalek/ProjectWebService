package com.health.calculator;

import javax.jws.WebService;
import java.time.LocalDate;
import java.time.Period;

@WebService
public class HealthService {

    // Display user's full information as formatted HTML string
    public String displayUserInfo(String name, String id, String gender, double weightKg, double heightCm, int age) {
        return "User Information:<br>" +
                "Name: " + name + "<br>" +
                "ID: " + id + "<br>" +
                "Gender: " + gender + "<br>" +
                "Weight: " + weightKg + " kg<br>" +
                "Height: " + heightCm + " cm<br>" +
                "Age: " + age + " years<br>";
    }

    // Calculate age from Malaysian IC Number format (YYMMDD-XXXXXX or YYMMDDXXXXXX)
    public int calculateAgeFromIC(String icNumber) {
        try {
            // Remove non-digit characters in case of hyphens or spaces
            String digitsOnly = icNumber.replaceAll("\\D", "");
            if (digitsOnly.length() < 6) {
                throw new IllegalArgumentException("IC Number is too short");
            }

            String birthDateStr = digitsOnly.substring(0, 6);
            int year = Integer.parseInt(birthDateStr.substring(0, 2));
            int month = Integer.parseInt(birthDateStr.substring(2, 4));
            int day = Integer.parseInt(birthDateStr.substring(4, 6));

            // Adjust century: assume year < 25 is 2000+, else 1900+
            year += (year < 25) ? 2000 : 1900;

            LocalDate birthDate = LocalDate.of(year, month, day);
            LocalDate today = LocalDate.now();

            if (birthDate.isAfter(today)) {
                throw new IllegalArgumentException("Birthdate cannot be in the future");
            }

            return Period.between(birthDate, today).getYears();
        } catch (Exception e) {
            throw new RuntimeException("Invalid IC format. Please use YYMMDD-XXXXXX or YYMMDDXXXXXX.", e);
        }
    }

    // Calculate BMI using kg and cm
    public double calculateBMI(double weightKg, double heightCm) {
        double heightM = heightCm / 100.0;
        return weightKg / (heightM * heightM);
    }

    // Calculate Body Fat Percentage based on BMI, age, and gender
    public double calculateBodyFat(double bmi, int age, String gender) {
        if ("male".equalsIgnoreCase(gender)) {
            return (1.20 * bmi) + (0.23 * age) - 16.2;
        } else {
            return (1.20 * bmi) + (0.23 * age) - 5.4;
        }
    }

    // Return daily calories based on goal
    public int calculateCalories(String goal) {
        switch (goal.toLowerCase()) {
            case "weight_loss": return 1800;
            case "maintenance": return 2200;
            case "muscle_gain": return 2600;
            default: return 2000;
        }
    }

    // Return meal plan suggestions based on goal
    public String generateMealPlan(String goal) {
        switch (goal.toLowerCase()) {
            case "weight_loss":
                return "Oatmeal, Grilled Chicken Salad, Steamed Vegetables";
            case "maintenance":
                return "Eggs, Chicken Sandwich, Rice with Veggies";
            case "muscle_gain":
                return "Pancakes, Steak, Pasta with Meatballs";
            default:
                return "Balanced Diet";
        }
    }

    // Track steps: return how many steps remaining to reach goal
    public int trackSteps(int currentSteps, int goalSteps) {
        return goalSteps - currentSteps;
    }
}
