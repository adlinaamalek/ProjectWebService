package com.cal;

import com.health.calculator.HealthService;
import com.health.calculator.HealthService.InvalidICException;
import com.health.calculator.HealthService.InvalidInputException;
import com.health.calculator.HealthService.InvalidStepDataException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "Client", urlPatterns = {"/Client"})
public class Client extends HttpServlet {
    private HealthService service = new HealthService();
    
        @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            switch (action) {
                case "userinfo":
                    handleUserInfo(request, response);
                    break;
                case "calculateage":
                    handleAgeFromIC(request, response);
                    break;
                case "bmi":
                    handleBMI(request, response);
                    break;
                case "bodyfat":
                    handleBodyFat(request, response);
                    break;
                case "caloriesburn":
                    handleCaloriesBurn(request, response);
                    break;
                case "steptracker":
                    handleSteps(request, response);
                    break;
                case "mealplanner":
                    handleMealPlanner(request, response);
                    break;
                default:
                    request.setAttribute("error", "Unknown action");
                    request.getRequestDispatcher("error.jsp").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "Exception: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    private void handleUserInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("name", request.getParameter("name"));
        request.setAttribute("id", request.getParameter("id"));
        request.setAttribute("gender", request.getParameter("gender"));
        request.setAttribute("weight", Double.parseDouble(request.getParameter("weight")));
        request.setAttribute("height", Double.parseDouble(request.getParameter("height")));
        request.setAttribute("age", Integer.parseInt(request.getParameter("age")));
        request.getRequestDispatcher("userinfo.jsp").forward(request, response);
    }

    private void handleAgeFromIC(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String ic = request.getParameter("ic");
            int age = service.calculateAgeFromIC(ic);
            request.setAttribute("ic", ic); // Pass IC to JSP
            request.setAttribute("age", age);
            request.getRequestDispatcher("calculateage.jsp").forward(request, response);
        } catch (InvalidICException e) {
            request.setAttribute("error", "Invalid IC: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    private void handleBMI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            double weight = Double.parseDouble(request.getParameter("weight"));
            double height = Double.parseDouble(request.getParameter("height"));

            double bmi = service.calculateBMI(weight, height);
            String category = service.getBMICategory(bmi);
            String formattedBMI = String.format("%.2f", bmi);
             
            request.setAttribute("weight", weight);
            request.setAttribute("height", height);
            request.setAttribute("bmi", formattedBMI);
            request.setAttribute("category", category);
            request.getRequestDispatcher("bmi.jsp").forward(request, response);
        } catch (InvalidInputException | IllegalArgumentException e) {
            request.setAttribute("error", "BMI Error: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

        private void handleBodyFat(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            try {
                String gender = request.getParameter("gender");
                double height = Double.parseDouble(request.getParameter("height"));
                double waist = Double.parseDouble(request.getParameter("waist"));
                double neck = Double.parseDouble(request.getParameter("neck"));
                double hip = gender.equalsIgnoreCase("female") ?
                        Double.parseDouble(request.getParameter("hip")) : 0.0;

                double bodyFat = service.calculateBodyFatUSNavy(gender, height, waist, neck, hip);
                String category = service.getBodyFatCategory(bodyFat, gender);

                request.setAttribute("bodyFat", bodyFat);
                request.setAttribute("category", category);
                request.getRequestDispatcher("bodyfat.jsp").forward(request, response);
            } catch (InvalidInputException | IllegalArgumentException e) {
                request.setAttribute("error", "Body Fat Error: " + e.getMessage());
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
        }

 private void handleCaloriesBurn(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    try {
        String activity = request.getParameter("activity");
        double met = Double.parseDouble(request.getParameter("met"));
        double weight = Double.parseDouble(request.getParameter("weight"));
        double duration = Double.parseDouble(request.getParameter("duration"));

        double caloriesBurned = service.calculateCaloriesBurned(met, weight, duration);

        request.setAttribute("activity", activity);
        request.setAttribute("caloriesBurned", caloriesBurned);
        request.getRequestDispatcher("calories.jsp").forward(request, response);

    } catch (IllegalArgumentException e) {
        // Penting: gunakan nama attribute "error" (sama dengan JSP)
        request.setAttribute("error", "Calories Error: " + e.getMessage());
        request.getRequestDispatcher("calories.jsp").forward(request, response);
    }
}

 private void handleSteps(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    try {
        int currentSteps = Integer.parseInt(request.getParameter("currentSteps"));
        int goalSteps = Integer.parseInt(request.getParameter("goalSteps"));
        double stepLength = Double.parseDouble(request.getParameter("stepLength"));
        double weight = Double.parseDouble(request.getParameter("weight"));
        double duration = Double.parseDouble(request.getParameter("duration"));

        int stepsRemaining = goalSteps - currentSteps;
        double distanceMeters = currentSteps * (stepLength / 100.0); // convert cm to meters

        // Pass to JSP
        request.setAttribute("currentSteps", currentSteps);
        request.setAttribute("goalSteps", goalSteps);
        request.setAttribute("stepsRemaining", stepsRemaining);
        request.setAttribute("stepLength", stepLength);
        request.setAttribute("weight", weight);
        request.setAttribute("duration", duration);
        request.setAttribute("distanceMeters", distanceMeters);

        request.getRequestDispatcher("steps.jsp").forward(request, response);
    } catch (NumberFormatException e) {
        request.setAttribute("error", "Invalid number format: " + e.getMessage());
        request.getRequestDispatcher("error.jsp").forward(request, response);
    } catch (Exception e) {
        request.setAttribute("error", "Unexpected error: " + e.getMessage());
        request.getRequestDispatcher("error.jsp").forward(request, response);
    }
}

    
    private void handleMealPlanner(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            double weight = Double.parseDouble(request.getParameter("weight"));
            double height = Double.parseDouble(request.getParameter("height"));
            int age = Integer.parseInt(request.getParameter("age"));
            String gender = request.getParameter("gender");
            String activityLevel = request.getParameter("activityLevel");
            String goal = request.getParameter("goal");

            double bmr = service.calculateBMR(weight, height, age, gender);
            double activityFactor = service.getActivityFactor(activityLevel);
            double tdee = service.calculateTDEE(bmr, activityFactor);
            double goalCalories = service.calculateCalorieGoal(tdee, goal);

            // Fix: This name must match with what meal.jsp expects
            request.setAttribute("caloriesNeeded", goalCalories);
            request.setAttribute("goal", goal);

            request.getRequestDispatcher("meal.jsp").forward(request, response);

        } catch (Exception e) {
            request.setAttribute("error", "Meal Plan Error: " + e.getMessage());
            request.getRequestDispatcher("meal.jsp").forward(request, response);
        }
    }
}