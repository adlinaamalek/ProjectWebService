package com.health.calculator;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.WebFault;
import java.time.LocalDate;
import java.time.Period;

@WebService(serviceName = "HealthService")
public class HealthService {

    @WebMethod(operationName = "calculateAgeFromIC")
    public int calculateAgeFromIC(String ic) throws InvalidICException {
        if (ic == null || ic.length() < 6) {
            throw new InvalidICException("Invalid IC format");
        }

        String digitsOnly = ic.replaceAll("\\D", "");
        String birthDateStr = digitsOnly.substring(0, 6);

        int year, month, day;
        try {
            year = Integer.parseInt(birthDateStr.substring(0, 2));
            month = Integer.parseInt(birthDateStr.substring(2, 4));
            day = Integer.parseInt(birthDateStr.substring(4, 6));
        } catch (Exception e) {
            throw new InvalidICException("IC does not contain valid date digits");
        }

        year += (year <= 25) ? 2000 : 1900;

        LocalDate birthDate;
        try {
            birthDate = LocalDate.of(year, month, day);
        } catch (Exception e) {
            throw new InvalidICException("Invalid birthdate from IC");
        }

        LocalDate today = LocalDate.now();

        if (birthDate.isAfter(today)) {
            throw new InvalidICException("Birthdate cannot be in the future");
        }

        return Period.between(birthDate, today).getYears();
    }

    @WebMethod
    public double calculateBMI(double weight, double height) {
        if (weight <= 0 || height <= 0) {
            throw new IllegalArgumentException("Weight and height must be greater than 0.");
        }
        double heightInMeters = height / 100.0;
        return weight / (heightInMeters * heightInMeters);
    }

    @WebMethod(operationName = "getBMICategory")
    public String getBMICategory(double bmi) throws InvalidInputException {
        if (bmi < 0) throw new InvalidInputException("BMI cannot be negative.");
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal weight";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }

    @WebMethod(operationName = "calculateBodyFatUSNavy")
    public double calculateBodyFatUSNavy(String gender, double heightCm, double waistCm, double neckCm, double hipCm) {
        if (gender == null || heightCm <= 0 || waistCm <= 0 || neckCm <= 0) {
            throw new IllegalArgumentException("Invalid input: gender and measurements must not be null or zero.");
        }

        if ("male".equalsIgnoreCase(gender)) {
            if (waistCm <= neckCm) {
                throw new IllegalArgumentException("For males, waist must be greater than neck.");
            }
            return 86.010 * Math.log10(waistCm - neckCm) - 70.041 * Math.log10(heightCm) + 36.76;
        } else if ("female".equalsIgnoreCase(gender)) {
            if (hipCm <= 0) {
                throw new IllegalArgumentException("Hip measurement required for females.");
            }
            if (waistCm + hipCm <= neckCm) {
                throw new IllegalArgumentException("For females, waist + hip must be greater than neck.");
            }
            return 163.205 * Math.log10(waistCm + hipCm - neckCm) - 97.684 * Math.log10(heightCm) - 78.387;
        } else {
            throw new IllegalArgumentException("Gender must be 'male' or 'female'.");
        }
    }

    @WebMethod(operationName = "getBodyFatCategory")
    public String getBodyFatCategory(double bodyFatPercentage, String gender) throws InvalidInputException {
        if (bodyFatPercentage < 0 || gender == null ||
            (!gender.equalsIgnoreCase("male") && !gender.equalsIgnoreCase("female"))) {
            throw new InvalidInputException("Invalid input: check gender or body fat value.");
        }

        if (gender.equalsIgnoreCase("male")) {
            if (bodyFatPercentage < 6) return "Essential fat";
            else if (bodyFatPercentage <= 24) return "Fitness";
            else return "Obese";
        } else {
            if (bodyFatPercentage < 14) return "Essential fat";
            else if (bodyFatPercentage <= 31) return "Fitness";
            else return "Obese";
        }
    }

    @WebMethod(operationName = "calculateCaloriesBurned")
    public double calculateCaloriesBurned(double met, double weightKg, double durationMinutes) {
        if (met <= 0 || weightKg <= 0 || durationMinutes <= 0) {
            throw new IllegalArgumentException("All inputs must be greater than zero.");
        }
        return (met * 3.5 * weightKg / 200) * durationMinutes;
    }

    @WebMethod(operationName = "trackSteps")
    public String trackSteps(String userId, int steps) throws InvalidStepDataException {
        if (userId == null || userId.isEmpty() || steps <= 0) {
            throw new InvalidStepDataException("User ID must not be empty and steps must be positive.");
        }
        return "User " + userId + " has taken " + steps + " steps.";
    }

    @WebMethod(operationName = "suggestMealPlan")
    public String suggestMealPlan(int calories) throws InvalidInputException {
        if (calories <= 0) throw new InvalidInputException("Calories must be greater than zero.");
        if (calories < 1500) return "Low Calorie Meal Plan";
        else if (calories <= 2500) return "Balanced Meal Plan";
        else return "High Calorie Meal Plan";
    }

    @WebMethod(operationName = "calculateCalorieGoal")
    public double calculateCalorieGoal(double maintenanceCalories, String goalType) {
        if (maintenanceCalories <= 0 || goalType == null || goalType.isEmpty()) {
            throw new IllegalArgumentException("Invalid inputs for calorie goal calculation.");
        }

        switch (goalType.toLowerCase()) {
            case "weight_loss":
            case "lose":
                return maintenanceCalories - 500;
            case "maintenance":
            case "maintain":
                return maintenanceCalories;
            case "muscle_gain":
            case "gain":
                return maintenanceCalories + 500;
            default:
                throw new IllegalArgumentException("Invalid goal type. Use 'weight_loss', 'maintenance', or 'muscle_gain'.");
        }
    }

    @WebMethod(operationName = "calculateBMR")
    public double calculateBMR(double weightKg, double heightCm, int age, String gender) {
        if (weightKg <= 0 || heightCm <= 0 || age <= 0 || gender == null) {
            throw new IllegalArgumentException("Invalid input: weight, height, and age must be > 0 and gender must not be null.");
        }

        if ("male".equalsIgnoreCase(gender)) {
            return 88.362 + (13.397 * weightKg) + (4.799 * heightCm) - (5.677 * age);
        } else if ("female".equalsIgnoreCase(gender)) {
            return 447.593 + (9.247 * weightKg) + (3.098 * heightCm) - (4.330 * age);
        } else {
            throw new IllegalArgumentException("Gender must be 'male' or 'female'.");
        }
    }

    @WebMethod(operationName = "getActivityFactor")
    public double getActivityFactor(String level) {
        switch (level.toLowerCase()) {
            case "sedentary": return 1.2;
            case "lightly active":
            case "light": return 1.375;
            case "moderately active":
            case "moderate": return 1.55;
            case "very active": return 1.725;
            case "extra active":
            case "active": return 1.9;
            default: throw new IllegalArgumentException("Invalid activity level.");
        }
    }

    @WebMethod(operationName = "calculateTDEE")
    public double calculateTDEE(double bmr, double activityMultiplier) {
        if (bmr <= 0 || activityMultiplier <= 0) {
            throw new IllegalArgumentException("BMR and activity multiplier must be greater than zero.");
        }
        return bmr * activityMultiplier;
    }

    @WebMethod(exclude = true)
    public double calculateCaloriesBurned(double weight, double duration, String activity) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @WebMethod(exclude = true)
    public int trackSteps(int currentSteps, int goalSteps) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // Custom exception class for IC-related errors
    @WebFault(name = "InvalidICException")
    public static class InvalidICException extends Exception {
        public InvalidICException(String message) { super(message); }
        public InvalidICException(String message, Throwable cause) { super(message, cause); }
    }

    // Custom exception class for step tracking
    @WebFault(name = "InvalidStepDataException")
    public static class InvalidStepDataException extends Exception {
        public InvalidStepDataException(String message) { super(message); }
        public InvalidStepDataException(String message, Throwable cause) { super(message, cause); }
    }

    // Custom exception for general invalid input
    @WebFault(name = "InvalidInputException")
    public static class InvalidInputException extends Exception {
        public InvalidInputException(String message) { super(message); }
        public InvalidInputException(String message, Throwable cause) { super(message, cause); }
    }
}
